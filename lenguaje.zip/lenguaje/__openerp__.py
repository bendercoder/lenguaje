{
    'name':'Estacionamiento',
    'version':'1.0',
    'depends':['base_setup'],
    'author': 'Jowar Rivera',
    'category':'',
    'description': """
    Módulo Estacionamiento 2da Evaluación de Lenguaje de Programación II
    """,
    'update_xml':[],
    "data": [
        "views/estacionamiento_views.xml",
        "views/carro_views.xml",
    ],
    'installable': True,
    'auto_install': False,
}
